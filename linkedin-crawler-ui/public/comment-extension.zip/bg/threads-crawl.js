// Cào bài Threads theo TỪ KHOÁ (Threads không có "group" như Facebook/LinkedIn).
// Với mỗi từ khoá: mở trang threads.com/search?q=<từ khoá> trong 1 tab riêng, nhờ
// platforms/threads/crawl.js gom bài (JSON của trang + GraphQL khi cuộn), rồi gửi lên
// POST /api/all-platform/extension/threads/save-posts để backend lọc (trùng, quá cũ),
// ưu tiên tương tác và lưu. Lệnh từ trang web: MK_TH_CRAWL_START / STOP / STATUS;
// báo về trang web: MK_TH_CRAWL_LOG / PROGRESS / SAVED / DONE (cùng khuôn MK_LI_CRAWL_*).
// Bọc IIFE: background.js importScripts file này vào CHUNG global scope của service worker.
(function () {
    const API_KEY = "markee-extension-key-2024";
    const DEFAULT_API_BASE = "https://seeding.markeeai.com";
    const TAB_LOAD_TIMEOUT_MS = 30000;
    const SETTLE_DELAY_MS = 2500;
    const INTER_KEYWORD_DELAY_MS = 1500;

    let running = false;
    let shouldStop = false;
    let crawlTabId = null;
    let crawlWindowId = null;
    let dashboardTabId = null;
    // Từ khoá đang cào - gắn vào lô bài crawl.js đẩy về (MK_TH_COLLECT_BATCH) để web biết
    // bài thuộc từ khoá nào khi hiện danh sách realtime.
    let currentKeyword = "";

    function sleep(ms) {
        return new Promise((r) => setTimeout(r, ms));
    }

    function notifyApp(message) {
        if (dashboardTabId != null) {
            chrome.tabs.sendMessage(dashboardTabId, message).catch(() => {});
            return;
        }
        chrome.tabs.query({}, (tabs) => {
            tabs.forEach((tab) => {
                if (tab.id !== crawlTabId) chrome.tabs.sendMessage(tab.id, message).catch(() => {});
            });
        });
    }

    function log(message, level = "info") {
        console.log("[Threads Crawl]", message);
        notifyApp({ action: "MK_TH_CRAWL_LOG", level, message });
    }

    function waitForTabLoad(tabId, timeoutMs) {
        return new Promise((resolve) => {
            let done = false;
            function finish(ok) {
                if (done) return;
                done = true;
                chrome.tabs.onUpdated.removeListener(listener);
                clearTimeout(timer);
                resolve(ok);
            }
            function listener(updatedTabId, changeInfo) {
                if (updatedTabId === tabId && changeInfo.status === "complete") finish(true);
            }
            chrome.tabs.onUpdated.addListener(listener);
            const timer = setTimeout(() => finish(false), timeoutMs);
        });
    }

    function buildSearchUrl(keyword, sortRecent) {
        const cleanKw = (keyword || "").trim();
        const params = new URLSearchParams();
        params.set("q", cleanKw);
        params.set("serp_type", "default");
        // Mode recent đảm bảo lấy bài viết mới nhất và hiện đại nhất theo yêu cầu
        if (sortRecent !== false) {
            params.set("filter", "recent");
        }
        return `https://www.threads.com/search?${params.toString()}`;
    }

    async function collectFromTab(tabId, targetCount, maxScrolls = 15, maxAgeDays = 7) {
        const message = {
            action: "MK_TH_COLLECT_POSTS",
            targetCount,
            maxScrolls: Number(maxScrolls) > 0 ? Number(maxScrolls) : 15,
            maxAgeDays: Number(maxAgeDays) > 0 ? Math.floor(Number(maxAgeDays)) : 7,
        };
        try {
            return await chrome.tabs.sendMessage(tabId, message);
        } catch (e) {
            // crawl.js chưa có trong tab (vd extension vừa cài/cập nhật) -> tiêm tay rồi thử lại.
            await chrome.scripting.executeScript({ target: { tabId }, files: ["platforms/threads/crawl.js"] });
            await sleep(500);
            return chrome.tabs.sendMessage(tabId, message);
        }
    }

    // "API 40 · JSON trang 18 · DOM 3 (DOM bổ sung dữ liệu còn thiếu cho 2 bài) · 4 lần cuộn, 3 response API (BarcelonaSearchResultsRefetchableQuery x3)"
    function describeSources(result) {
        const parts = [`API ${result.fromApi || 0}`, `JSON trang ${result.fromJson || 0}`, `DOM ${result.fromDom || 0}`];
        if (result.domEnriched) parts[2] += ` (DOM bổ sung dữ liệu còn thiếu cho ${result.domEnriched} bài)`;
        const names = (result.apiNames || []).map((n) => `${n.name} x${n.count}`).join(", ");
        parts.push(`${result.scrolls || 0} lần cuộn, ${result.apiResponses || 0} response API${names ? ` (${names})` : ""}`);
        return parts.join(" · ");
    }

    async function postToBackend(apiBase, body) {
        let lastError = null;
        for (let attempt = 0; attempt <= 2; attempt++) {
            try {
                const res = await fetch(`${apiBase}/api/all-platform/extension/threads/save-posts`, {
                    method: "POST",
                    headers: { "Content-Type": "application/json", "x-api-key": API_KEY },
                    body: JSON.stringify(body),
                });
                const data = await res.json().catch(() => ({}));
                if (!res.ok) throw new Error(data.detail ? String(data.detail) : `HTTP ${res.status}`);
                return data;
            } catch (e) {
                lastError = e;
                if (attempt < 2) {
                    log(`Gửi hệ thống lỗi (${e.message}), thử lại lần ${attempt + 1}/2...`, "warn");
                    await sleep(2000);
                }
            }
        }
        throw lastError;
    }

    async function runCrawl(keywords, config) {
        // Xem giai thich o fb-crawl.js: khi goi truc tiep tu rotation-crawl.js,
        // dashboardTabId phai duoc truyen qua config, khong de mac dinh null/broadcast-all.
        if (config.dashboardTabId != null) dashboardTabId = config.dashboardTabId;
        const apiBase = config.apiBase || DEFAULT_API_BASE;
        const postLimit = Number(config.postLimit) > 0 ? Math.min(100, Math.floor(Number(config.postLimit))) : 20;
        const maxAgeDays = Number(config.maxAgeDays) > 0 ? Math.floor(Number(config.maxAgeDays)) : 7;
        const sortRecent = config.sortRecent !== false;
        // Gom dư ra (x3) vì backend còn lọc bài trùng/bài cũ rồi mới cắt theo post_limit.
        const targetCount = Math.min(Math.max(postLimit * 3, 30), 150);

        let totalPosts = 0;
        let totalSaved = 0;
        let loginHintShown = false;
        let wasStopped = false;

        // Bao tien do chi tiet cho rotation-crawl.js (neu dang chay qua lich xoay vong)
        // theo doi va hien thi ro rang len UI - xem self.__mkThreadsProgressHook.
        const reportProgress = (keywordIndex) => {
            if (typeof self.__mkThreadsProgressHook === "function") {
                self.__mkThreadsProgressHook({ groupIndex: keywordIndex, totalGroups: keywords.length, savedSoFar: totalSaved });
            }
        };

        try {
            log(`Bắt đầu tìm bài Threads cho ${keywords.length} từ khoá (tối đa ${postLimit} bài mới/từ khoá)...`);
            for (let i = 0; i < keywords.length; i++) {
                if (shouldStop) break;
                const keyword = keywords[i];
                currentKeyword = keyword;
                notifyApp({ action: "MK_TH_CRAWL_PROGRESS", groupIndex: i, totalGroups: keywords.length, keyword, posts: totalPosts });
                reportProgress(i);
                log(`[${i + 1}/${keywords.length}] Đang tìm: "${keyword}"`);

                const url = buildSearchUrl(keyword, sortRecent);
                if (crawlTabId == null) {
                    // Mo 1 cua so rieng, thu nho/khong focus - khong cuop focus cua
                    // tab/cua so nguoi dung dang dung (xem giai thich o fb-crawl.js).
                    const win = await chrome.windows.create({
                        url,
                        focused: false,
                        width: 1280,
                        height: 850,
                        left: 100,
                        top: 100,
                        type: "normal"
                    });
                    crawlWindowId = win.id;
                    crawlTabId = win.tabs && win.tabs[0] ? win.tabs[0].id : null;
                } else {
                    await chrome.tabs.update(crawlTabId, { url });
                }
                if (!(await waitForTabLoad(crawlTabId, TAB_LOAD_TIMEOUT_MS))) log("Tab Threads tải chậm, vẫn thử tiếp.", "warn");
                await sleep(SETTLE_DELAY_MS);
                if (shouldStop || crawlTabId == null) break;

                let result;
                try {
                    result = await collectFromTab(crawlTabId, targetCount, config.maxScrolls || 15, maxAgeDays);
                } catch (e) {
                    log(`Không đọc được trang kết quả: ${e.message}`, "error");
                    continue;
                }
                                if (result && result.circuitBreaker) {
                    log(`🚨 [CẦU DAO KHẨN CẤP THREADS] Instagram/Threads phát hiện hoạt động bất thường: "${result.error || 'Challenge/Checkpoint'}". DỪNG CÀO ĐỂ BẢO VỆ TÀI KHOẢN TUYỆT ĐỐI!`, "error");
                    notifyApp({
                        action: "MK_TH_CRAWL_CIRCUIT_BREAKER",
                        reason: result.error,
                        keyword
                    });
                    shouldStop = true;
                    break;
                }

                if (!result || !result.success) {
                    log(`Lỗi gom bài: ${(result && result.error) || "không có phản hồi"}`, "error");
                    continue;
                }
                if (result.loginWall && !loginHintShown) {
                    loginHintShown = true;
                    log('Chrome chưa đăng nhập Threads: mỗi từ khoá chỉ lấy được ~20 bài "nổi bật" đầu tiên (không cuộn thêm, không lọc được "Gần đây"). Đăng nhập threads.com để lấy nhiều bài mới hơn.', "warn");
                }

                const posts = result.data || [];
                totalPosts += posts.length;
                notifyApp({ action: "MK_TH_CRAWL_PROGRESS", groupIndex: i, totalGroups: keywords.length, keyword, posts: totalPosts });
                log(`Tìm thấy ${posts.length} bài cho "${keyword}" — ${describeSources(result)}.`);
                if (posts.length === 0) continue;

                try {
                    const saved = await postToBackend(apiBase, {
                        posts,
                        keyword,
                        id_member: config.idMember || null,
                        post_limit: postLimit,
                        max_age_days: maxAgeDays,
                        extension_version: `Markee-Seeding-Extension-${chrome.runtime.getManifest().version}`,
                    });
                    const count = saved.count || 0;
                    totalSaved += count;
                    const notes = [];
                    if (saved.skipped_existing) notes.push(`${saved.skipped_existing} bài đã có`);
                    if (saved.skipped_old) notes.push(`${saved.skipped_old} bài quá cũ`);
                    log(`Đã lưu ${count} bài mới cho "${keyword}"${notes.length ? ` (bỏ qua ${notes.join(", ")})` : ""}.`, "success");
                    notifyApp({ action: "MK_TH_CRAWL_SAVED", count, groupUrl: keyword, groupId: "" });
                } catch (e) {
                    log(`Lỗi lưu bài cho "${keyword}": ${e.message}`, "error");
                }
                reportProgress(i + 1);
                const kwDelayMs = (config.groupRestSec != null && Number(config.groupRestSec) >= 15)
                    ? Number(config.groupRestSec) * 1000
                    : (Math.floor(Math.random() * 17000) + 18000);
                log(`🛡️ Chống bot sinh học Threads: Chờ an toàn ${(kwDelayMs / 1000).toFixed(1)}s trước khi tìm từ khoá tiếp theo...`);
                await sleep(kwDelayMs);
            }
            log(shouldStop ? `Đã dừng. Tổng đã lưu: ${totalSaved} bài mới.` : `Hoàn tất! Tổng đã lưu: ${totalSaved} bài mới.`, "success");
        } catch (e) {
            log(`Lỗi nghiêm trọng: ${e.message}`, "error");
        } finally {
            wasStopped = shouldStop;
            const windowId = crawlWindowId;
            running = false;
            shouldStop = false;
            crawlTabId = null;
            crawlWindowId = null;
            if (windowId != null) chrome.windows.remove(windowId).catch(() => {});
            notifyApp({ action: "MK_TH_CRAWL_DONE", totalGroups: keywords.length, totalPosts, totalSaved, stopped: wasStopped });
        }
        return { totalGroups: keywords.length, totalPosts, totalSaved, stopped: wasStopped };
    }

    // Cho phep bg/rotation-crawl.js goi truc tiep va await - xem giai thich o fb-crawl.js.
    self.__mkStartThreadsCrawl = runCrawl;
    self.__mkStopThreadsCrawl = () => {
        if (!running) return;
        shouldStop = true;
        stopCollectInTab();
    };
    self.__mkThreadsCrawlStatus = () => running;

    function stopCollectInTab() {
        if (crawlTabId != null) chrome.tabs.sendMessage(crawlTabId, { action: "MK_TH_COLLECT_STOP" }).catch(() => {});
    }

    chrome.tabs.onRemoved.addListener((tabId) => {
        if (running && tabId === crawlTabId) {
            crawlTabId = null;
            shouldStop = true;
            log("Tab cào Threads bị đóng — đã dừng.", "warn");
        }
    });

    chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
        if (!msg) return;
        if (msg.action === "MK_TH_COLLECT_BATCH") {
            // Lô bài crawl.js vừa gom được trong tab cào -> chuyển nguyên cho trang web.
            if (running && sender.tab && sender.tab.id === crawlTabId) {
                notifyApp({ action: "MK_TH_CRAWL_POSTS", keyword: currentKeyword, posts: msg.posts || [], keywordTotal: msg.total || 0 });
            }
            return;
        }
        if (msg.action === "MK_TH_CRAWL_START") {
            if (running) {
                sendResponse({ success: false, error: "Đang có một tiến trình cào Threads chạy." });
                return;
            }
            const seen = new Set();
            const keywords = (msg.keywords || [])
                .map((k) => String(k || "").trim())
                .filter((k) => k && !seen.has(k.toLowerCase()) && seen.add(k.toLowerCase()));
            if (keywords.length === 0) {
                sendResponse({ success: false, error: "Chưa có từ khoá nào để tìm." });
                return;
            }
            running = true;
            shouldStop = false;
            dashboardTabId = sender.tab ? sender.tab.id : null;
            sendResponse({ success: true, total: keywords.length });
            runCrawl(keywords, msg.config || {});
            return;
        }
        if (msg.action === "MK_TH_CRAWL_STOP") {
            if (running) {
                shouldStop = true;
                stopCollectInTab();
                log("Đã nhận lệnh dừng, sẽ lưu nốt bài đã gom của từ khoá hiện tại rồi dừng...", "warn");
            }
            sendResponse({ success: true });
            return;
        }
        if (msg.action === "MK_TH_CRAWL_STATUS") {
            sendResponse({ running });
        }
    });
})();
